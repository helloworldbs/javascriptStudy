// Data Type 
// 1. String 

let str1 = 'a';
let str2 = "";
let str3 = `${str1}`;

// 2. Number 
let num1 = 10;
let num2 = 3.14;
let num3 = NaN;
let num4 = Infinity;

// 3.boolean - true, false
let bool1 = true;
let bool2 = false;

// 4. undefined : 변수 선언 O 값은 할당 X 
let undi;
console.log(undi);

// 5. null : 변수 선언 O, 값의 할당 null 
let nul = null;
console.log(nul);

// 6. Object 객체 데이터 { key : value }
let obj = {
    snack : "cookie",
    day : {
        month : 7,
        day : 9,
        today : 'TUE'
    }
}

console.log(obj);
console.log(obj.day);


// 7. Array 배열 데이터 [ index 0, 1,2,3,...]
let arr1 = [1,2,3,"hello"];
console.log(arr1);
console.log(arr1[0]);
console.log(arr1.length);
console.log(arr1[arr1.length - 1]);